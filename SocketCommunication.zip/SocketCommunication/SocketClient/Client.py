import json
import socket
import ClientJson

ClientSocket = socket.socket()

def initialize_client():
    host = '127.0.0.1'
    port = 1222

    print('Initializing Client connection')
    try:
        ClientSocket.connect((host, port))
    except socket.error as e:
        print(str(e))
    Response = ClientSocket.recv(1024)

def send_commands_to_server():
    flag = False
    start_req = ClientJson.get_start_request()
    print("Sending Request :: "+ start_req)
    ClientSocket.send(str.encode(start_req))
    Response = ClientSocket.recv(1024)
    resp_str = Response.decode('utf-8')
    resp_json = json.loads(resp_str)
    print("Recieved Response :: "+resp_str)
    if resp_json["method"] == "Initialization Success":
        flag = True
    while flag:
        Input = input('Enter a linux Command to Execute on server ::  ')
        req_str = ClientJson.get_request(Input)
        print("Sending request :: "+req_str)
        ClientSocket.send(str.encode(req_str))
        Response = ClientSocket.recv(1024)
        resp_str = Response.decode('utf-8')
        print("Recieved Response :: "+resp_str)

def close_client_connection():
    ClientSocket.close()

if __name__ == "__main__":
    initialize_client()
    send_commands_to_server()