from typing import Dict
import json


unique_id = "233EB-DFEEC-4455A-BBACE-7725A" #Id should be change for each client

def get_start_request():
    request = {}
    request["action"] = "connect"
    request["id"] = unique_id
    request["method"] = "Initializing Connection"
    json_str = json.dumps(request, indent = 2)
    return json_str

def get_request(cmd):
    if "," in cmd:
        return send_request_arr(cmd.split(","))
    request = {}
    request["action"] = "start"
    request["id"] = unique_id
    request["method"] = cmd
    json_str = json.dumps(request, indent = 2)
    return json_str

def send_request_arr(arr):
    result = []
    for cmd in arr:
        json_obj = json.loads(get_request(cmd.strip()))
        result.append(json_obj)
    result = json.dumps(result, indent = 2)
    return result
    