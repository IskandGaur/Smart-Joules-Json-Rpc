import json
import socket
import os
from _thread import *
import ServerJson

ServerSocket = socket.socket()

def initializeSocket():
    host = '127.0.0.1'
    port = 1222
    try:
        ServerSocket.bind((host, port))
    except socket.error as e:
        print(str(e))
    print('Initializing Server Connection..')
    ServerSocket.listen(5)


def threaded_client(connection, threadNo):
    print("Initialized thread && thread no ::"+str(threadNo))
    connection.send(str.encode('Welcome to the Servern'))
    while True:
        data = connection.recv(2048)
        data = data.decode('utf-8')
        print("Recieved Request :: "+data)
        json_str = json.loads(data)
        reply = data;
        if(type(json_str) is not list and json_str["action"] == "connect"):
            reply = ServerJson.get_start_response(json_str)
        elif type(json_str) is list:
            reply = ServerJson.runcommands_and_getresp(json_str)
        else:
            reply = ServerJson.runcommand_and_getresp(json_str)
        if not data:
            break
        print("Sending Response :: "+reply)
        connection.sendall(str.encode(reply))
    connection.close()

def checkForClientConnection():
    thread_cnt = 1
    while True:
        Client, address = ServerSocket.accept()
        print('Connected to: ' + address[0] + ':' + str(address[1]))
        start_new_thread(threaded_client, (Client, thread_cnt,  ))
        thread_cnt += 1
        print('Thread Number: ' + str(thread_cnt))

def closeSocket():
    ServerSocket.close()


if __name__ == "__main__":
    initializeSocket()
    checkForClientConnection()
