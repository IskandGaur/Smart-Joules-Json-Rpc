import json
import os
import subprocess

def get_start_response(obj):
    response = {}
    response["action"] = "connect"
    response["method"] = "Initialization Success"
    response["id"] = obj["id"]
    json_str = json.dumps(response, indent = 2)
    return json_str


def runcommand_and_getresp(data):
    response = {}
    response["action"] = "start"
    response["request-method"] = data["method"]
    response["id"] = data["id"]
    executeCommand(response, data["method"]);
    json_str = json.dumps(response, indent = 2)
    return json_str

def runcommands_and_getresp(data):
    response = []
    for d in data:
        json_str = runcommand_and_getresp(d)
        json_obj = json.loads(json_str)
        response.append(json_obj)
    return json.dumps(response, indent = 2)

def executeCommand(response, cmd):
    try:
        resp = subprocess.check_output(cmd.split(" "))
        response["response"] = str(resp)
        response["response-status"] = "success"
    except Exception as err:
        response["response-error"] = str(err)
        response["response-status"] = "failure"
